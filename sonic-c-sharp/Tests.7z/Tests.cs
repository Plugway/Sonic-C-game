using System;
using System.Collections.Generic;
using System.Diagnostics;
using NUnit.Framework;
using System.Windows.Forms;

namespace sonic_c_sharp
{
    [TestFixture]
    public class Tests
    {
	    private void InitiateTestEnvironment()
	    {
		    Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
		    
		    GameState.ObjectList = new List<GameObject>();
		    GameState.ObjectsToRemove = new List<GameObject>();
		    GameState.ObjectsToAdd = new List<GameObject>();
            
		    GameState.MotobugsList = new List<GameObject>();
		    GameState.MotobugsToRemove = new List<GameObject>();
            
		    Resources.LoadResources("testsLevel.txt");
		    GameState.FindSonicObject();
		    GameState.LinkToSonicObject.InitializeSonicCollisionBoxes();
		    GameState.LinkToSonicObject.CurrentCollisionBoxesSet = GameState.LinkToSonicObject.StandingCollisionBoxes;
		    Background.InitiateBackground();
				
			Application.EnableVisualStyles();       
	    }
	    
		[Test]
		public void Print()
		{	
			InitiateTestEnvironment();
			var TestForm = new GameForm();
			//TestForm.RightIsPressed = true;
			Application.Run(TestForm);
			
			Assert.Greater(GameState.LinkToSonicObject.XSpeed, 0);
		}
	    
	    [Test]
	    public void Print2()
	    {
		    InitiateTestEnvironment();
		    var TestForm = new GameForm();
		    //TestForm.RightIsPressed = true;
		    Application.Run(TestForm);
		    
		    Assert.AreEqual(0, GameState.LinkToSonicObject.XSpeed);
	    }
	    
	    [Test]
	    public void Print3()
	    {
		    InitiateTestEnvironment();
		    var TestForm = new GameForm();
		    //TestForm.RightIsPressed = true;
		    Application.Run(TestForm);
		    
		    Assert.AreEqual(0, GameState.LinkToSonicObject.XSpeed);
	    }
	}
}